package com.campus.meet.NSU.exception;

public class MeetNsuException extends RuntimeException{
    public MeetNsuException(String message){
        super(message);
    }
}
